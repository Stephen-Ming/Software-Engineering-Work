#pragma once
#include<iostream>
#include<string>
using namespace std;
class txl
{
private:
	int num;
	string name;
	string sex;
	int age;
	string tel;
	string h_tel;
public:
	txl(void);
	~txl(void);
	void setvalue();//����
	void add();//����
	int inqure(int item,string n_or_t);
	void change(int item);//����
	//void del();//ɾ��
	void output();
	friend istream &operator >>(istream&,txl&);
	friend ostream &operator <<(ostream&,txl&);
};

