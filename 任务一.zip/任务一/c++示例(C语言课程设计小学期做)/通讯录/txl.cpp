#include "txl.h"


txl::txl(void)
{
	num=0;
	name="***";
	age=0;
	tel="Not set";
	h_tel="Not set";
}


txl::~txl(void)
{
}


void txl::setvalue()//������Ϣ
{
	cout<<"num:";
	cin>>num;
	cout<<"name:";
	cin>>name;
	cout<<"sex:";
	cin>>sex;
	cout<<"age:";
	cin>>age;
	cout<<"tel:";
	cin>>tel;
	cout<<"h_tel:";
	cin>>h_tel;
}


void txl::output()//�����Ϣ
{
	cout<<"num:";
	cout<<num<<endl;
	cout<<"name:";
	cout<<name<<endl;
	cout<<"sex:";
	cout<<sex<<endl;
	cout<<"age:";
	cout<<age<<endl;
	cout<<"tel:";
	cout<<tel<<endl;
	cout<<"h_tel:";
	cout<<h_tel<<endl;
}




int txl::inqure(int item,string n_or_t)//��ѯ��Ϣ
{
	if(item==1)
	{
		if(n_or_t.compare(name)==0)
			return 1;
		else return 0;
	}
	else if(item==2)
	{
		if(n_or_t.compare(tel)==0)
			return 2;
		else return 0;
	}
	else return 0;
}



void txl::change(int item)
{
	switch(item)
	{
	case 1:
		cin>>num;
		break;
	case 2:
		cin>>sex;
		break;
	case 3:
		cin>>age;
		break;
	case 4:
		cin>>tel;
		break;
	case 5:
		cin>>h_tel;
		break;
	default:
		cout<<"�������"<<endl;
	}
}

istream &operator >>(istream& input,txl& a)
{
	cout<<"num:\n";
	input>>a.num;
	cout<<"name:\n";
	input>>a.name;
	cout<<"sex:\n";
	input>>a.sex;
	cout<<"age:\n";
	input>>a.age;
	cout<<"tel:\n";
	input>>a.tel;
	cout<<"h_tel:\n"; 
	input>>a.h_tel;
	return input;                                                              
};

ostream &operator <<(ostream &output,txl &a)
{
	cout;
	output<<"num:"<<a.num<<"\nname:"<<a.name<<"\nsex:"<<a.sex<<"\nage:"<<a.age<<"\ntel:"<<a.tel<<"\nh_tel:"<<a.h_tel<<endl<<endl;
	return output;
};