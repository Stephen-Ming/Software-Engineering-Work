package txtedit;
import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  
  
public class Font1 extends JDialog implements ItemListener
{  
    /** 
     *  
     */  
	    private static final long serialVersionUID = 1L;  
	    JPanel panel1 = new JPanel();  
	    JPanel panel2 = new JPanel();  
	    JPanel panel3 = new JPanel();  
	    JComboBox comboBox1 = new JComboBox();  
	    JComboBox comboBox2 = new JComboBox();  
	    JComboBox comboBox3 = new JComboBox();  
	    JLabel lab1=new JLabel("���壺");  
	    JLabel lab2=new JLabel("���Σ�");  
	    JLabel lab3=new JLabel("�ֺţ�");  
	    String name=new String("΢���ź�");  
	    Font f1=new Font("΢���ź�",Font.PLAIN,15);  
	    int style=1;  
	    int size=12;  
	    String []array2=new String[]{"����","��б","�Ӵ�"};  
	    String []array3=new String[]{"14","15","15","16","17","18"};  
	    //��ȡϵͳ��������
	    GraphicsEnvironment ge=GraphicsEnvironment.getLocalGraphicsEnvironment();  
	    String [] fontName=ge.getAvailableFontFamilyNames();  
	    JButton b1=new JButton("ȷ��");  
	    JButton b2=new JButton("��ɫ");  
	    JTextArea a1=new JTextArea();  
	    void set(JTextArea n)
	    {  
	        a1=n;  
	    }  
	    public Font1()
	    {  
	    	setBackground(Color.WHITE);
	        setTitle("����");  
	        setLocation(200,60);
	        setSize(400,300);  
	        this.setResizable(false);
	        setLayout(new FlowLayout());  
	        //panel1.setLocation(100, 200);  
	        lab1.setFont(f1);  
	        lab2.setFont(f1);  
	        comboBox1.setModel(new DefaultComboBoxModel(fontName)); 
	        comboBox1.setBackground(Color.WHITE);
	        comboBox1.setFocusable(false);
	        comboBox1.setFont(f1);  
	        for(int i=1;i<fontName.length;i++)
	        {  
	            //comboBox1.setSelectedIndex(i);  
	            comboBox1.setSelectedItem(fontName);  
	           
	            //comboBox1.addItem(fontName);  
	        }  
	        comboBox2.setModel(new DefaultComboBoxModel(array2));  
	        comboBox2.setBackground(Color.WHITE);
	        comboBox2.setFocusable(false);
	        comboBox2.setFont(f1);  
	        for(int i=1;i<array2.length;i++){  
	            //comboBox2.setSelectedIndex(i);  
	            comboBox2.setSelectedItem(array2);  
	            //comboBox2.addItem(array2);  
	        }  
	        comboBox3.setModel(new DefaultComboBoxModel(array3));  
	        comboBox3.setFocusable(false);
	        comboBox3.setBackground(Color.WHITE);
	        comboBox3.setFont(f1);  
	        for(int i=1;i<array3.length;i++){  
	            //comboBox2.setSelectedIndex(i);  
	            comboBox2.setSelectedItem(array3);  
	            //comboBox3.addItem(array3);  
	        }  
	          
	        panel1.add(lab1);  
	        panel1.add(comboBox1);  
	        panel2.add(lab2);  
	        panel2.add(comboBox2);  
	        panel3.add(lab3);  
	        panel3.add(comboBox3);  
	        panel3.add(b1);  
	        panel3.add(b2);  
	        b2.addActionListener(new MyActionListener3());  
	        b2.setBackground(Color.WHITE);
	        b2.setFocusable(false);
	        comboBox1.addItemListener(this);  
	        comboBox2.addItemListener(this);  
	        comboBox3.addItemListener(this);  
	        b1.setBackground(Color.WHITE);
	        b1.setFocusable(false);
	        b1.addActionListener(new MyActionListener3());  
	        add(panel1);  
	        add(panel2);  
	        add(panel3);  
	    }  
        public void itemStateChanged(ItemEvent e) 
        {  
            if(e.getSource()==comboBox1)
            {  
                name=comboBox1.getSelectedItem().toString();  
            }  
            if(e.getSource()==comboBox2)
            {  
            	String s1=comboBox2.getSelectedItem().toString();  
	            if(s1.equals("�Ӵ�"))
	            {  
	            	style=Font.BOLD;  
	            }  
	            if(s1.equals("��б"))
	            {  
	                style=Font.ITALIC;  
	            }  
	            if(s1.equals("����"))
	            {  
	                style=Font.PLAIN;  
	            }  
            }  
            if(e.getSource()==comboBox3)
            {  
                 String s2=comboBox3.getSelectedItem().toString();  
                 size=Integer.parseInt(s2);  
            }  
              
        }  
          
        class MyActionListener3 implements ActionListener
        {  
            public void actionPerformed(ActionEvent e2)
            {  
            	 if(e2.getActionCommand()=="ȷ��")
                 {  
            		 Font f=new Font(name,style,size);  
            		 a1.setFont(f);
                 }  
                  
                if(e2.getActionCommand()=="��ɫ")
                {  
                    setcolor();  
                }  
            }  
        }  
       void setcolor()
       {  
    	   Color   fontcolor=JColorChooser.showDialog(this,"������ɫѡ��",a1.getForeground());  
    	   a1.setForeground(fontcolor);  
       }  
       
       void main(String arg[])
       {
    	   //TODO ����
    	   
    	   Font1 f=new Font1();
    	   f.setVisible(true);
       }
    }  